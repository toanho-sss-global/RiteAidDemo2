define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** preShow defined for map1 **/
    AS_FlexContainer_ha1f146d1aa540959bfeb954047f2ec0: function AS_FlexContainer_ha1f146d1aa540959bfeb954047f2ec0(eventobject) {
        var self = this;
        this.addLocationsToMap();
    }
});