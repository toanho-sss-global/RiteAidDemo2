define(function() {

	return {

	};
});